extern "C" int errno;
int errno;
