//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resources.rc
//
#define IDB_ZOOMIN_OUT                  10000
#define IDB_ZOOMIN_DOWN                 10001
#define IDB_ZOOMIN_OVER                 10002
#define IDB_ZOOMOUT_OUT                 10003
#define IDB_ZOOMOUT_DOWN                10004
#define IDB_ZOOMOUT_OVER                10005
#define IDB_ZOOMPAGE_OUT                10006
#define IDB_ZOOMPAGE_DOWN               10007
#define IDB_ZOOMPAGE_OVER               10008
#define IDB_ZOOM11_OUT                  10009
#define IDB_ZOOM11_DOWN                 10010
#define IDB_ZOOM11_OVER                 10011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        10012
#define _APS_NEXT_COMMAND_VALUE         30001
#define _APS_NEXT_CONTROL_VALUE         20007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
