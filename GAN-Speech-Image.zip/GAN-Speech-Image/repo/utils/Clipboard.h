#ifndef CLIPBOARD_H
#define CLIPBOARD_H

class DibImage;

/**
 Provides access to the windows clip board. Right now only bitmaps are implemented.
 */
class Clipboard
{
public:
    Clipboard();
    ~Clipboard();

    // CF_TEXT, CF_DIB, CF_BITMAP
    // ... windows converts between DIB/BITMAP for you.
    bool isFormatAvailable( unsigned format );
    bool copy(HWND hwnd, DibImage* dib );
    DibImage* getDib(HWND hwnd);
};

#endif // CLIPBOARD_H
