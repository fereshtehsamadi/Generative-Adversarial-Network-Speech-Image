#include "ListItem.h"

ListItem::ListItem()
{
    _selected = false;

}


ListItem::~ListItem()
{

}

void 
ListItem::select( bool sel )
{
    _selected = sel;
}

bool
ListItem::isSelected()
{
    return _selected;
}

