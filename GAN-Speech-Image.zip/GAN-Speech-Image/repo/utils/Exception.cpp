#include "Exception.h"

Exception::Exception()
{


}


Exception::Exception( const std::_tstring& str ) : msg(str)
{

}
