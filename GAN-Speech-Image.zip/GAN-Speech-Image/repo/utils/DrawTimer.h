#ifndef DRAW_TIMER_H
#define DRAW_TIMER_H

#include "Timer.h"

class DrawTimer
{
public:
    static unsigned RegisterEvent( TimerEvent* event );
    static void CancelEvent(TimerEvent* event);

private:
	static VOID CALLBACK TimerManagerProc(HWND hwnd, UINT uMsg, UINT idEvent, 
            DWORD dwTime);
};

#endif // DRAW_TIMER_H
