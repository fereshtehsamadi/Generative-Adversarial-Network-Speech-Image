#ifndef DBG_H
#define DBG_H
#include "debug.h"

#define DDISK 'd'

#endif // DBG_H
